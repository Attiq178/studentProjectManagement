﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace StudentProjectManagement
{
    public partial class Evaluation : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if(conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            if (!IsPostBack)
            {
                ddlProjects_SelectedIndexChanged(sender, e);
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Project from Groups";// where group_Status = 0";// where Category='Advisor'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                foreach (DataRow tempRow in dt.Rows)
                {
                    ddlProjects.Items.Add(tempRow["Project"].ToString());
                }
                conn.Close();
            }
        }

        protected void ddlProjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ddlProjects.SelectedIndex > 0)
            {
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * from Groups where Project = '" + ddlProjects.Text + "' ";

                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                foreach (DataRow tempRow in dt.Rows)
                {
                    lblStudents.Text = tempRow["Students"].ToString();
                    lblAdvisor.Text = tempRow["Advisor"].ToString();
                    lblCoAdvisor.Text = tempRow["Co_Advisor"].ToString();
                    lblPreEvMarks.Text = tempRow["Evaluation"].ToString();

                }
                conn.Close();
            }
            else
            {
                Response.Write("Project is not selected.");
                lblStudents.Text = lblAdvisor.Text = lblCoAdvisor.Text = txtObMarks.Text = txtTMarks.Text = "";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if(txtObMarks.Text != "" ||  txtTMarks.Text != "")
            {
                double obMarks = Convert.ToDouble(txtObMarks.Text);
                double tMarks = Convert.ToDouble(txtTMarks.Text);
                //Response.Write("Marks: " + obMarks + "<br>Total Marks: " + tMarks);
                //calculating percentage
                double perc = obMarks / tMarks * 100;
                //Response.Write("Percentage " + perc + "%");
                conn.Open();

                SqlCommand cmd = conn.CreateCommand();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Evaluation from Groups where Project = '" + ddlProjects.Text + "' ";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                double mrks = Convert.ToDouble(dt.Rows[0]["Evaluation"].ToString());
                //Response.Write("Marks::::::" + mrks);
                double FinalMarks;
                if (mrks > 0)
                {
                    Response.Write("Your Average Marks: " + (mrks + perc) / 2);
                    FinalMarks = (mrks + perc) / 2;
                }
                else
                {
                    FinalMarks = perc;
                }


                cmd.CommandText = "update Groups set Evaluation = '" + FinalMarks + "' where Project = '" + ddlProjects.Text + "' ";

                cmd.ExecuteNonQuery();
                conn.Close();
                txtObMarks.Text = txtTMarks.Text = "";
            }
            else
            {
                Response.Write("Please fill the fields of marks");
            }
        }
    }
}
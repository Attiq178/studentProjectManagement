﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace StudentProjectManagement
{
    public partial class Project : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack) //for only once when page is loaded first time
            {
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Name from Person where Category='Advisor'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                foreach (DataRow tempRow in dt.Rows)
                {
                    ddlAdvisor.Items.Add(tempRow["Name"].ToString());
                }

                cmd.CommandText = "Select Name from Person where Category='Co-advisor'";
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                foreach (DataRow tempRow in dt1.Rows)
                {
                    ddlCoAdvisor.Items.Add(tempRow["Name"].ToString());
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Projects values('" + txtTitle.Text + "','" + txtDescription.Text + "','"
                + ddlAdvisor.Text + "','" + ddlCoAdvisor.Text + "', '0' )";

            cmd.ExecuteNonQuery();
            txtTitle.Text = txtDescription.Text = "";
            ddlAdvisor.ClearSelection();
            ddlCoAdvisor.ClearSelection();
            conn.Close();
        }

        protected void ddlAdvisor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Response.Write("This is hello");
            //lblMsg.Text = ddlAdvisor.Text;
            //if(ddlAdvisor.SelectedIndex > 0)
            //{

            //}
        }
    }
}
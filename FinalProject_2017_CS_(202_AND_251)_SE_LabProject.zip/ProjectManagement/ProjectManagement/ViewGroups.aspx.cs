﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Data;
using System.Data.SqlClient;


namespace ProjectManagement
{
    public partial class ViewGroups : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select Project, Advisor, Co_Advisor, Students, Evaluation from Groups";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
           
            GridView1.DataSource = dt;
            GridView1.DataBind();

            cmd.CommandText = "Select Name, Reg_no, Gender, Phone, Email from Person where Category='Student'";
            cmd.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt1);

            GridView2.DataSource = dt1;
            GridView2.DataBind();

            cmd.CommandText = "Select Title, Description, Advisor, Co_Advisor from Projects";
            cmd.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt2);

            GridView3.DataSource = dt2;
            GridView3.DataBind();
        }

        public void pdfConvertor(GridView evaluationNumberGrid, string filename)
        {
            PdfPTable pdfTable = new PdfPTable(evaluationNumberGrid.HeaderRow.Cells.Count);

            foreach (TableCell hc in evaluationNumberGrid.HeaderRow.Cells)
            {
                PdfPCell pc = new PdfPCell(new Phrase(hc.Text));
                pdfTable.AddCell(pc);
            }

            foreach (GridViewRow gdr in evaluationNumberGrid.Rows)
            {
                foreach (TableCell tc in gdr.Cells)
                {
                    PdfPCell pc = new PdfPCell(new Phrase(tc.Text));

                    pdfTable.AddCell(pc);
                }
            }
            Document pdfDocument = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
            PdfWriter.GetInstance(pdfDocument, Response.OutputStream);
            pdfDocument.Open();
            pdfDocument.Add(pdfTable);
            pdfDocument.Close();
            Response.ContentType = "application/pdf";
            Response.AppendHeader("content-disposition", "attachment; FileName= " + filename +"Report.pdf");
            Response.Write(pdfDocument);
            Response.Flush();
            Response.End();
        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            pdfConvertor(GridView1, "Evaluation_");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            pdfConvertor(GridView2, "Students_");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            pdfConvertor(GridView3, "Projects_");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ProjectManagement
{
    
    public partial class Groups : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            if (!IsPostBack)
            {
                ddlProjects_SelectedIndexChanged(sender, e);
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Title from Projects where group_Status = 0";// where Category='Advisor'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                foreach (DataRow tempRow in dt.Rows)
                {
                    ddlProjects.Items.Add(tempRow["Title"].ToString());
                }

                cmd.CommandText = "Select Name from Person where Category='Student' AND group_Status = 0"; // where Category='Co-advisor'";
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                foreach (DataRow tempRow in dt1.Rows)
                {
                    ddlStudents.Items.Add(tempRow["Name"].ToString());
                }
                conn.Close();
            }

        }
        static List<string> stdList = new List<string>();
        static int std = 1;
        protected void btnCreate_Click(object sender, EventArgs e)
        {
            string students = string.Join(",", stdList.ToArray());
            //Response.Write("This is final Array: " + stdList);

            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Groups values('" + ddlProjects.Text + "','" + lblAdvisor.Text
                + "','" + lblCoAdvisor.Text + "','" + students + "', '0')";

            cmd.ExecuteNonQuery();

            //chaging status of students and project.
            cmd.CommandText = "update Projects set group_Status = 1 where Title = '" + ddlProjects.Text + "' ";
            cmd.ExecuteNonQuery();
            foreach (string std in stdList)
            {
                cmd.CommandText = "update Person set group_Status = '1' where Name = '" + std.ToString() + "' AND Category = 'Student'";
                cmd.ExecuteNonQuery();
            }
            std = 1;
            stdList.Clear();
            conn.Close();
            Response.Write("Group has been created successfully");
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (std < 5)
            {
                lstStudents.Items.Add(std + "." + ddlStudents.Text);
                std++;
                stdList.Add(ddlStudents.Text);
            }
            else
            {
                lblMsg.Text = "More than 4 in one group are not allowed.<br>Please create the group.";
            }
        }    
    protected void ddlProjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAdvisor.Text = lblCoAdvisor.Text = "Not selected yet";
            if (ddlProjects.SelectedIndex > 0)
            {
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Advisor, Co_Advisor from Projects where Title ='" + ddlProjects.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                lblAdvisor.Text = dt.Rows[0]["Advisor"].ToString();
                lblCoAdvisor.Text = dt.Rows[0]["Co_Advisor"].ToString();
                conn.Close();
            }
        }
    }
}
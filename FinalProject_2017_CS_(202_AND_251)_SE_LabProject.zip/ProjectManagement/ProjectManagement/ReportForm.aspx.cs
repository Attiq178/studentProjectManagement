﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ProjectManagement
{
    public partial class ReportForm : System.Web.UI.Page
    {
        //SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            //report rprt = new report();
            //CrystalReportViewer1.
        }
    }
}
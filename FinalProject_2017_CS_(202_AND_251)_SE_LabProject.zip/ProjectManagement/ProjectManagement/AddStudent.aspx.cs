﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ProjectManagement
{
    public partial class AddStudent : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            conn.Open();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            errorMsg.Text = "";
            if(name.Text != "" && (txtregNo.Text != "" || txtrank.Text != "") && txtphone.Text != "" && txtEmail.Text != "")
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into person values('" + name.Text + "','" + txtregNo.Text + "','"
                    + txtrank.Text + "','" + radioGender.Text + "','" + txtphone.Text + "','" + txtEmail.Text + "','"
                    + ddlistCategory.Text + "', '0')";

                cmd.ExecuteNonQuery();

                name.Text = "";
                txtregNo.Text = "";
                txtrank.Text = "";
                txtphone.Text = "";
                txtEmail.Text = "";
                radioGender.ClearSelection();
                errorMsg.Text = "Data has been added successfully";
            }
            else
            {
                errorMsg.Text = "Please fill all the fields.";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //Project prjct = new Project();
            ////prjct.Sh
            //Response.Redirect("Project.aspx");
        }

        protected void ddlistCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlistCategory.Text == "Select one option...")
            {
                lblMsg.Text = "Choose Option Please";
            }
            else if (ddlistCategory.Text == "Student")
            {
                lblMsg.Text = "Welcome Dear Student";
            }
            else if (ddlistCategory.Text == "Advisor" || ddlistCategory.Text == "Co-advisor")
            {
                lblMsg.Text = "Welcome Sir";
            }

        }
    }
}
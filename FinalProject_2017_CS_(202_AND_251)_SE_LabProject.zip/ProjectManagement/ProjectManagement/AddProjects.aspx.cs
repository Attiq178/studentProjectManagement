﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ProjectManagement
{

    public partial class AddProjects : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=StudentProjectsManagement;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            if (!IsPostBack) //for only once when page is loaded first time
            {
                SqlCommand cmd = new SqlCommand();
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select Name from Person where Category='Advisor'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                foreach (DataRow tempRow in dt.Rows)
                {
                    ddlAdvisor.Items.Add(tempRow["Name"].ToString());
                }

                cmd.CommandText = "Select Name from Person where Category='Co-advisor'";
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                foreach (DataRow tempRow in dt1.Rows)
                {
                    ddlCoAdvisor.Items.Add(tempRow["Name"].ToString());
                }
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if(txtProjectTitle.Text != "" && txtDescription.Text != "" && ddlAdvisor.SelectedIndex > 0 && ddlCoAdvisor.SelectedIndex > 0)
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Projects values('" + txtProjectTitle.Text + "','" + txtDescription.Text + "','"
                    + ddlAdvisor.Text + "','" + ddlCoAdvisor.Text + "', '0' )";

                cmd.ExecuteNonQuery();
                conn.Close();
                txtProjectTitle.Text = txtDescription.Text = "";
                lblMsg.Text = "Project has been added successfully.";
            }
            else
            {
                lblMsg.Text = "Please fill the fields.";
            }
        }
    }
}